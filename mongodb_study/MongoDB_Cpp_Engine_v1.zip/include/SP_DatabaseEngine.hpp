/********************************************************************
	The GoingGame Copyright (c) 2012 HiGame Team, All Rights reserved.
	created:	2012:6:18 10:49
	filename: 	SP_DatabaseEngine
	author:		koangel
	
	purpose:	���ݿ�ģ�͵Ľӿ��ļ�
*********************************************************************/
#pragma once

// ���⹫���ӿ�
#include "DE_DatabaseEngine.h"